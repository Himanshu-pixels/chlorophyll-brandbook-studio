-- chlorophyll brandbook studio — database setup
-- ALREADY APPLIED to the Supabase project "chlorophyll-brandbook-studio" (edrixkluesapamimzyst).
-- Keep this file for reference, or run it in the SQL editor of a NEW Supabase project to recreate the setup.

-- ---------- Team membership ----------
create table public.allowed_domains (domain text primary key);
create table public.invites (email text primary key, role text not null default 'editor' check (role in ('admin','editor')), invited_by uuid references auth.users on delete set null, created_at timestamptz not null default now());
create table public.members (user_id uuid primary key references auth.users on delete cascade, email text not null, role text not null default 'editor' check (role in ('admin','editor')), created_at timestamptz not null default now());

-- Anyone signing up with this domain joins automatically. Change or add domains here (or later in the app's Team page).
insert into public.allowed_domains(domain) values ('chlorophyll.in');

create or replace function public.is_member() returns boolean language sql stable security definer set search_path = '' as $$
  select exists(select 1 from public.members where user_id = (select auth.uid()));
$$;
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path = '' as $$
  select exists(select 1 from public.members where user_id = (select auth.uid()) and role = 'admin');
$$;

-- Joins the signed-in user to the team if invited or on an allowed domain. The first member becomes admin.
create or replace function public.claim_membership() returns text language plpgsql security definer set search_path = '' as $$
declare uid uuid := auth.uid(); em text; inv_role text; r text;
begin
  if uid is null then return null; end if;
  select role into r from public.members where user_id = uid; if r is not null then return r; end if;
  select email into em from auth.users where id = uid;
  if em is null then return null; end if;
  select role into inv_role from public.invites where lower(email) = lower(em);
  if inv_role is null and not exists(select 1 from public.allowed_domains where lower(domain) = lower(split_part(em, '@', 2))) then return null; end if;
  r := coalesce(inv_role, 'editor');
  if not exists(select 1 from public.members) then r := 'admin'; end if;
  insert into public.members(user_id, email, role) values (uid, em, r) on conflict (user_id) do nothing;
  return r;
end; $$;

-- ---------- Content ----------
create table public.brands (id text primary key, name text not null default '', data jsonb not null, created_by uuid default auth.uid() references auth.users on delete set null, updated_at timestamptz not null default now());
create table public.brand_pages (brand_id text not null references public.brands(id) on delete cascade, page_id text not null, data jsonb not null, updated_at timestamptz not null default now(), primary key (brand_id, page_id));
create index brand_pages_brand_idx on public.brand_pages(brand_id);
create table public.published (slug text primary key check (slug ~ '^[a-z0-9-]{2,64}$'), brand_id text not null, access text not null default 'public' check (access in ('public','password')), title text, description text, brand jsonb, pages jsonb, enc jsonb, published_by uuid default auth.uid() references auth.users on delete set null, published_at timestamptz not null default now());
create index published_brand_idx on public.published(brand_id);

-- ---------- Row level security ----------
alter table public.allowed_domains enable row level security;
alter table public.invites enable row level security;
alter table public.members enable row level security;
alter table public.brands enable row level security;
alter table public.brand_pages enable row level security;
alter table public.published enable row level security;

create policy "admins read domains" on public.allowed_domains for select to authenticated using ((select public.is_admin()));
create policy "admins manage domains" on public.allowed_domains for all to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));
create policy "admins manage invites" on public.invites for all to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));
create policy "members see team" on public.members for select to authenticated using ((select public.is_member()) or user_id = (select auth.uid()));
create policy "admins update members" on public.members for update to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));
create policy "admins remove members" on public.members for delete to authenticated using ((select public.is_admin()) and user_id <> (select auth.uid()));

create policy "team reads brands" on public.brands for select to authenticated using ((select public.is_member()));
create policy "team creates brands" on public.brands for insert to authenticated with check ((select public.is_member()));
create policy "team updates brands" on public.brands for update to authenticated using ((select public.is_member())) with check ((select public.is_member()));
create policy "team deletes brands" on public.brands for delete to authenticated using ((select public.is_member()));
create policy "team reads pages" on public.brand_pages for select to authenticated using ((select public.is_member()));
create policy "team creates pages" on public.brand_pages for insert to authenticated with check ((select public.is_member()));
create policy "team updates pages" on public.brand_pages for update to authenticated using ((select public.is_member())) with check ((select public.is_member()));
create policy "team deletes pages" on public.brand_pages for delete to authenticated using ((select public.is_member()));
create policy "anyone reads published" on public.published for select to anon, authenticated using (true);
create policy "team publishes" on public.published for insert to authenticated with check ((select public.is_member()));
create policy "team updates published" on public.published for update to authenticated using ((select public.is_member())) with check ((select public.is_member()));
create policy "team unpublishes" on public.published for delete to authenticated using ((select public.is_member()));

-- ---------- Grants ----------
revoke all on public.brands, public.brand_pages, public.members, public.invites, public.allowed_domains from anon;
revoke insert, update, delete, truncate on public.published from anon;
grant select on public.published to anon;
grant select, insert, update, delete on public.brands, public.brand_pages, public.published, public.invites, public.allowed_domains to authenticated;
grant select, update, delete on public.members to authenticated;
revoke execute on function public.claim_membership(), public.is_member(), public.is_admin() from public, anon;
grant execute on function public.claim_membership(), public.is_member(), public.is_admin() to authenticated;

-- ---------- File storage (public read so published brandbooks show images; team-only write) ----------
insert into storage.buckets (id, name, public, file_size_limit) values ('brand-assets', 'brand-assets', true, 52428800) on conflict (id) do nothing;
create policy "team uploads assets" on storage.objects for insert to authenticated with check (bucket_id = 'brand-assets' and (select public.is_member()));
create policy "team updates assets" on storage.objects for update to authenticated using (bucket_id = 'brand-assets' and (select public.is_member()));
create policy "team deletes assets" on storage.objects for delete to authenticated using (bucket_id = 'brand-assets' and (select public.is_member()));
